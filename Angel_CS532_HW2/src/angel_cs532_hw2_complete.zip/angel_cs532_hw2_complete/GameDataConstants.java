/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package angel_cs532_hw2_complete;

/**
 *
 * @author Arvin
 */
public interface GameDataConstants {

    public static final int AUTO_LOSE = -1;
    public static final int ROCK = 1;
    public static final int PAPER = 2;
    public static final int SCISSOR = 3;
    public static final int PLAYER1_WON = 1;
    public static final int PLAYER2_WON = 2;
    public static final int DRAW = 4;
    public static final String STRING_IMAGE_ROCK = "rock.jpg";
    public static final String STRING_IMAGE_PAPER = "paper.jpg";
    public static final String STRING_IMAGE_SCISSOR = "scissor.jpg";
}
